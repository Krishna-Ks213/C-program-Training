#include <iostream>

using namespace std;
class rectanagle{
    public :

        float area(float length, float breadth){
            return length * breadth;
}
float perimeter(float length, float breadth)
{
    return 2 * (length + breadth);
}
}
;

int main()
{
    rectanagle r;
    float length, breadth;
    cout << "enter the lenght of the rectangle" << endl;
    cin >> length;

    cout << "enter the breadth of the rectangle";
    cin >> breadth;

    cout << "area =" << r.area(length, breadth) << endl;
    cout << "perimeter" << r.perimeter(length, breadth) << endl;

    return 0;
}