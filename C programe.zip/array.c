#include<stdio.h>
#include<stdlib.h>
int main(){
int arr[]=(12,45,7,89,23);
int n=5;
int max = arr[0],min=arr[0];
for (int i=1; i<n; i++) {
if (arr[i]>max)
    max=arr[i];
 if (arr[i]<min)
    min=arr[i];
 }
 printf("maximum=%d\n",max);
 printf("minimum=%d\n",min);
 return 0;
 }