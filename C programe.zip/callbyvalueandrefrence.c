#include<stdio.h>
#include<stdlib.h>
void swap(int*a, int*b)
{
    int temp;
    temp=*a;
    *b=temp;
    *a=*b;
}
int main () {
    int x=9,y=10;
    swap(&x,&y);
    printf("%d %d",x,y);

}