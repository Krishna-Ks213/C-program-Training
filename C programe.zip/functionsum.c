#include<stdio.h>
#include<stdlib.h>

int add ( int a, int b){
    return a+b;
    }
 int main() {
    int result = add(10,30);
    printf("%d",result);
}