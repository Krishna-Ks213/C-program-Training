#include<stdio.h>
int main()
{
int n;
printf("enter the no.");
scanf("%d", &n);

if(n>90){
printf("gradeA");
}
else if (n==50)
{
printf("do better with hardwork");
}
else
{
printf("gradeB");
}

return 0;
}