#include<stdio.h>
int main()
{
int n,y;
printf("enter the no.");
scanf("%d", &n);
printf("enter the no");
scanf("%d",&y);

if(n>y){
printf("n is greatest no.");
}
else{
printf("n is not greatest no.");
}
return 0;
}