#include<stdio.h>
int main()
{
    int n;
    printf("enter the no.");
    scanf("%d", &n);
    
    if(n>0){
    printf("n is positive no.");
    }
    else{
    printf("n is negative");
    }
    return 0;
    }