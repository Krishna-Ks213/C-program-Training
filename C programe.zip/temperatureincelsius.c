#include<stdio.h>

int main()
{
    int f,c ;
    printf("enter the celsius value");
    scanf("%d", &c);
    f=(9.0/5.0)*c+32;
    printf(" value of ferenhiet=%f",f);
    
    return 0;
    }
   # mistakes in this code  
   1. commas
   2. formula in 9.0/5.0 not 9/5
   3. 5 line mein farehniet value ko integer mein 
   dena hai kyunki ussa farenhvo value 
   pta lagti hai
    