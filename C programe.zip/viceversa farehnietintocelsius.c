#include<stdio.h>

int main()
{
    float f,c ;
    printf("enter the farheniet value");
    scanf("%f",&f);
    printf("enter the celsius value"); 
    scanf("%f", &c);
    f=(9.0/5.0)*c+32;
    printf(" value of ferenhiet=%f",f);
    c=5.0/9.0*(f-32);
    printf("value of celsius=%f",c);

    return 0;
}
