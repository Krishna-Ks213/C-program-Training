// wap to search for a given element in the array
#include <stdio.h>
int main()
{
    int arr[] = {3, 4, 5, 2, 3};
    int key = 4;
    for (int i = 0; i < 5; i++)
    {
        if (arr[i] == key)
        {
            printf("Address = %p\n", (void *)&arr[i]);
        }
    }
    return 0;
}