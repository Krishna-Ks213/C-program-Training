#include <stdio.h>
#include <stdbool.h>

#define MAX 5  // Maximum capacity of the stack

// Defining the Stack structure
struct Stack {
    int arr[MAX];
    int top;
};

// Initialize the stack top index to -1
void initStack(struct Stack* stack) {
    stack->top = -1;
}

// Check if the stack is full
bool isFull(struct Stack* stack) {
    return stack->top == MAX - 1;
}

// Check if the stack is empty
bool isEmpty(struct Stack* stack) {
    return stack->top == -1;
}

// Add an element to the top of the stack
void push(struct Stack* stack, int value) {
    if (isFull(stack)) {
        printf("Stack Overflow! Cannot push %d\n", value);
        return;
    }
    stack->top++;
    stack->arr[stack->top] = value;
    printf("Pushed: %d\n", value);
}

// Remove and return the top element of the stack
int pop(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack Underflow! Cannot pop\n");
        return -1; // Return an error value
    }
    int poppedValue = stack->arr[stack->top];
    stack->top--;
    return poppedValue;
}

// View the top element without removing it
int peek(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty.\n");
        return -1;
    }
    return stack->arr[stack->top];
}

// Main function to run the program
int main() {
    struct Stack myStack;
    initStack(&myStack);

    // Testing Stack Operations
    push(&myStack, 10);
    push(&myStack, 20);
    push(&myStack, 30);
    
    printf("Top element: %d\n", peek(&myStack));
    
    printf("Popped: %d\n", pop(&myStack));
    printf("Popped: %d\n", pop(&myStack));
    
    printf("Top element after pops: %d\n", peek(&myStack));
    
    if (isEmpty(&myStack)) {
        printf("The stack is empty now.\n");
    } else {
        printf("The stack still has elements.\n");
    }

    return 0;
}