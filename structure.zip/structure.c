#include <stdio.h>
struct Student
{
    int roll;
    char name[30];
    float marks;
};
int main()
{
    struct Student s;
    printf("Enter Roll:");
    scanf("%d", &s.roll);

    printf("Enter Name:");
    scanf("%s", &s.name);

    printf("Enter Marks:");
    scanf("%f", &s.marks);

    printf("\nStudent Details\n");
    printf("Roll:%d\n", s.roll);
    printf("Name:%s\n", s.name);
    printf("Marks;%.f\n", s.marks);

    return 0;
}
